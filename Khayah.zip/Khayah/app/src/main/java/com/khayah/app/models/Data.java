package com.khayah.app.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Data {

@SerializedName("title")
@Expose
private String title;
@SerializedName("message")
@Expose
private String message;
@SerializedName("image_url")
@Expose
private String imageUrl;
@SerializedName("type")
@Expose
private String type;
@SerializedName("user_id")
@Expose
private String userId;
@SerializedName("latLng")
@Expose
private LatLng latLng;

public String getTitle() {
return title;
}

public void setTitle(String title) {
this.title = title;
}

public String getMessage() {
return message;
}

public void setMessage(String message) {
this.message = message;
}

public String getImageUrl() {
return imageUrl;
}

public void setImageUrl(String imageUrl) {
this.imageUrl = imageUrl;
}

public String getType() {
return type;
}

public void setType(String type) {
this.type = type;
}

public String getUserId() {
return userId;
}

public void setUserId(String userId) {
this.userId = userId;
}

public LatLng getLatLng() {
return latLng;
}

public void setLatLng(LatLng latLng) {
this.latLng = latLng;
}

}